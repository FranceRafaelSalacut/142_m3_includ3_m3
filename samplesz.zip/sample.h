#include "sample2.h"

void todo4();
void todo5(int,int);
void todo6(int,int);
void todo5(int,int,int);