#include "sample3.h"

void todo7();
void todo8(int,int);
void todo9(int,int);
void todo10(int,int,int);