#include "sample4.h"

void todo11();
void todo12(int,int);
void todo13(int,int);
void todo14(int,int,int);