void todo15();
void todo16(int,int);
void todo17(int,int);
void todo18(int,int,int);