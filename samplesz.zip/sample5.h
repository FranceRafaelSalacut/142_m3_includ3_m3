#include "sample6.h"

void todo5();
void todo6(int,int);
void todo7(int,int);
void todo8(int,int,int);