void todo19();
void todo20(int,int);