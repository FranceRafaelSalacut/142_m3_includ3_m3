#include "sample4.h"

void todo21();
void todo22(int,int);